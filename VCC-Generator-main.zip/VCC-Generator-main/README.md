# VCC-Generator(Valid Credit Card Generator)
VCC-Generator is a python script that generate VCC for testing purposes only<br>
Note:It can't be used for carting

<img src="Screenshot_20220112-193931.png" height="100%" width="100%">

<h2>Installation</h2>
<p>$ apt update && apt upgrade</p>
<p>$ apt install git && apt install python3</p>
<p>$ git clone https://github.com/spider863644/VCC-Generator</p>
<p>$ cd VCC-Generator</p>
<p>$ python3 VCC.py</p>

<h2>Credits</h2>
<p>AnonyminHack5<br>
Spider Anongreyhat</p>
<h3>Follow me on github for more tools</h3>
